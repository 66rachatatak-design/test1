# CyberSim — Cyber Security Simulator
This is a learning simulator for Thai high-school students to learn Cyber Security.
Built with React + Tailwind + Framer Motion.
