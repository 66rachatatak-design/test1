import React from 'react';
import ReactDOM from 'react-dom/client';
import CyberSimApp from './CyberSimApp.jsx';
import './index.css';

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <CyberSimApp />
  </React.StrictMode>
);